#!/bin/sh
#
# vim: expandtab ts=2 :

WEBSITE_UPLOADS='./website/_uploads'

while true
do
  test -d .git && break
  cd ..
done

set -e

make clean
make targz

# Defined in the root Makefile.
version="$(./offlineimap.py --version)"
abbrev="$(git log --format='%h' HEAD~1..)"
targz="../offlineimap-${version}-${abbrev}.tar.gz"

filename="offlineimap-v${version}.tar.gz"

mv -v "$targz" "${WEBSITE_UPLOADS}/${filename}"
cd "$WEBSITE_UPLOADS"
sha1sum "$filename" > "${filename}.sha1"
sha256sum "$filename" > "${filename}.sha256"
sha512sum "$filename" > "${filename}.sha512"
