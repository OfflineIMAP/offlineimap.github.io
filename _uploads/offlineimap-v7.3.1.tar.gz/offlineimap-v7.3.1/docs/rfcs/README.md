
All RFCs related to IMAP.

TODO: Add a brief introduction here to introduce the most important RFCs.
