
README
======

**This "./contrib" directory is where users share their own scripts and tools.**

Everything here is submitted and maintained *by the users for the users*. You're
welcome to add your own stuff. There is no barrier on your contributions here.
We think it's expected to find contributions of various quality.
