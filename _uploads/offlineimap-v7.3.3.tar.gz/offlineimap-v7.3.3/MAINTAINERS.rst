.. -*- coding: utf-8 -*-

Contacts
========

- Abdó Roig-Maranges
  - email: abdo.roig at gmail.com
  - github: aroig

- Ben Boeckel
  - email: mathstuf at gmail.com
  - github: mathstuf

- benutzer193
  - email: registerbn at gmail.com
  - github: benutzer193

- Chris Coleman
  - email: chris at espacenetworks.com
  - github: chris001

- Darshit Shah
  - email: darnir at gmail.com
  - github: darnir

- Eygene Ryabinkin
  - email: rea at freebsd.org
  - github: konvpalto
  - other: FreeBSD maintainer

- Igor Almeida
  - email: igor.contato at gmail.com
  - github: igoralmeida

- Ilias Tsitsimpis
  - email: i.tsitsimpis at gmail.com
  - github: iliastsi
  - other: Debian maintainer

- "J"
  - email: offlineimap at 927589452.de
  - github: 927589452
  - other: FreeBSD user

- Łukasz Żarnowiecki
  - email: dolohow at outlook.com
  - github: dolohow

- Nicolas Sebrecht
  - email: nicolas.s-dev at laposte.net
  - github: nicolas33
  - system: Linux

- Remi Locherer
  - email: remi.locherer at relo.ch
  - system: OpenBSD maintainer

- Sebastian Spaeth
  - email: sebastian at sspaeth.de
  - github: spaetz
  - other: left the project but still responding


Testers
=======

- Abdó Roig-Maranges
- Ben Boeckel
- Chris Coleman
- Darshit Shah
- Eygene Ryabinkin
- Igor Almeida
- Ilias Tsitsimpis
- "J"
- Łukasz Żarnowiecki
- Nicolas Sebrecht
- Remi Locherer


Maintainers
===========

- Eygene Ryabinkin
- Sebastian Spaeth
- Nicolas Sebrecht
- Chris Coleman


Github
------

- Eygene Ryabinkin
- Sebastian Spaeth
- Nicolas Sebrecht


Mailing List
------------

- Eygene Ryabinkin
- Sebastian Spaeth
- Nicolas Sebrecht


Twitter
-------

- Nicolas Sebrecht


Pypi
----

- Nicolas Sebrecht
- Sebastian Spaeth
