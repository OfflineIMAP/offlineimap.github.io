.. OfflineImap documentation master file
.. _OfflineIMAP: http://www.offlineimap.org


Welcome to OfflineIMAP's developer documentation
================================================

**License**
   :doc:`dco` (dco)

**Documented APIs**

.. toctree::
   API
   repository
   ui


.. moduleauthor:: John Goerzen, and many others. See AUTHORS and the git history for a full list.

:License: This module is covered under the GNU GPL v2 (or later).
